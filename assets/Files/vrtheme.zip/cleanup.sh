#!/sbin/sh
rm -R /sdcard/vrtheme/
echo "Cleanup complete"
